package com.example.microfinance.services

import android.content.Intent
import android.util.Log
import com.example.microfinance.activity.NotificationActivity
import com.example.microfinance.model.NotificationVO
import com.example.microfinance.utils.NotificationUtil
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class MyFirebaseMessagingService : FirebaseMessagingService() {

    val TAG = "MyFirebaseIdService"
    val TOPIC_GLOBAL = "global"
    val TITTLE = "title"
    val EMPTY = ""
    val MESSAGE = "message"
    val ACTION = "action"
    val DATA = "data"
    val ACTION_DESTINATION = "action_destination"

    override fun onMessageReceived(remoteMessage: RemoteMessage?) {

        // TODO(developer): Handle FCM messages here.
        // Not getting messages here? See why this may be: https://goo.gl/39bRNJ
        Log.d(TAG, "From: ${remoteMessage?.from}")

        // Check if message contains a data payload.
        remoteMessage?.data?.isNotEmpty()?.let {
            Log.d(TAG, "Message data payload: " + remoteMessage.data)
            val data = remoteMessage.data
            handleData(data)

        }

        // Check if message contains a notification payload.
        remoteMessage?.notification?.let {
            Log.d(TAG, "Message NotificationVO Body: ${it.body}")
            var notification = remoteMessage.notification
            handleNotification(notification!!)
        }

        // Also if you intend on generating your own notifications as a result of a received FCM
        // message, here is where that should be initiated. See sendNotification method below.
    }

    override fun onNewToken(token: String?) {
        super.onNewToken(token)
        val builder = StringBuilder()
        builder.append("Refreshed Token: ")
            .append(token)
        Log.d(TAG, builder.toString())

//        FirebaseMessaging.getInstance().subscribeToTopic(TOPIC_GLOBAL)
//            .addOnCompleteListener { task ->
//                var msg = "Succesful subscribed to " + TOPIC_GLOBAL
//                if (!task.isSuccessful) {
//                    msg = "Failed to subscribe to " + TOPIC_GLOBAL
//                }
//                Log.d(TAG, msg)
//                Toast.makeText(baseContext, msg, Toast.LENGTH_SHORT).show()
//            }
    }

    private fun handleNotification(RemoteMsgNotification: RemoteMessage.Notification){
        val message: String = RemoteMsgNotification.body.toString()
        val title: String = RemoteMsgNotification.title.toString()
        val notificationVO = NotificationVO(title,message,"","")

        val resultIntent = Intent(applicationContext, NotificationActivity::class.java)
        val notificationUtil = NotificationUtil(applicationContext)
        resultIntent.putExtra("message",message)
        notificationUtil.displayNotification(notificationVO, resultIntent)
//        notificationUtil.playNotificationSound()
    }

    private fun handleData(data: Map<String, String>){
        val title: String = data.get(TITTLE).toString()
        val message: String = data.get(MESSAGE).toString()
        val action: String = data.get(ACTION).toString()
        val actionDestination: String = data.get(ACTION_DESTINATION).toString()
        val notificationVO = NotificationVO(title,message,action,actionDestination)

        val resultIntent = Intent(applicationContext, NotificationActivity::class.java)
        resultIntent.putExtra("message",message)

        val notificationUtil = NotificationUtil(applicationContext)
        notificationUtil.displayNotification(notificationVO, resultIntent)
//        notificationUtil.playNotificationSound()
    }
}
