package com.example.michael.pepsiinventory;

public interface UserInterface {
    void getPosition(User user);
}
