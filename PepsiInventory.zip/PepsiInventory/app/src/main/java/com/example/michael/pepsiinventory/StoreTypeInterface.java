package com.example.michael.pepsiinventory;

public interface StoreTypeInterface {

    String getStoreType(String type);

}
