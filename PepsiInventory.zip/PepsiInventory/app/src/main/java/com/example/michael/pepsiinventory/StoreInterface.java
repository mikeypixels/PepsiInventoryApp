package com.example.michael.pepsiinventory;

public interface StoreInterface {
    void getPosition(Store store);
}
