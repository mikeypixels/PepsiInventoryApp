package com.example.microfinance.model

class NotificationVO(var title:String, var message:String, var action:String, var actionDestination:String)